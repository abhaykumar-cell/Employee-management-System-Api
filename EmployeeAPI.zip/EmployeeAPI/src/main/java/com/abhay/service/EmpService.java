package com.abhay.service;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abhay.entity.Emp;
import com.abhay.exception.EmpAlreadyExistsException;
import com.abhay.exception.NoSuchEmpExistsExeption;
import com.abhay.repository.EmpRepository;

@Service
public class EmpService {
	private EmpRepository empRepo;

	@Autowired
	public EmpService(EmpRepository empRepo) {
		
		this.empRepo = empRepo;
	}
	
	public String addEmp(Emp emp) {
		Emp e =empRepo.findByEname(emp.getEname()).orElse(null);
		if (e!=null) {
			throw new EmpAlreadyExistsException("Emp With "+emp.getEname()+"Already Exists");
			
		}
		else {
			empRepo.save(emp);
		}
		return "Emp Saved Successfully";
		
	}
	public Emp getEmp(Integer empId) {
		Emp e =empRepo.findById(empId).orElse(null);
		if (e==null) {
			throw new NoSuchEmpExistsExeption("Emp With id "+empId+"does not Exists");
			
		}
		
		return e;
		
	}
	
	public String updateEmp(Emp emp, Integer empId) {
		Emp e =empRepo.findById(empId).orElse(null);
		if(e==null) {
			throw new NoSuchElementException("Emp With id "+empId+"does not Exists");
		}
		else {
		e.setEname(emp.getEname());
		e.setEsal(emp.getEsal());
		empRepo.save(e);
		
		return"Emp Updated Successfully";
		}
	
	}
	}
	


