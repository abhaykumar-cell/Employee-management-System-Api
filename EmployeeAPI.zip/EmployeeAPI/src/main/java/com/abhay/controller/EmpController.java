package com.abhay.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.abhay.entity.Emp;
import com.abhay.exception.EmpAlreadyExistsException;
import com.abhay.exception.ErrorResponse;
import com.abhay.exception.NoSuchEmpExistsExeption;
import com.abhay.service.EmpService;

@RestController
@RequestMapping("/api/emp")
public class EmpController {
	private EmpService serv;

	@Autowired
	public EmpController(EmpService serv) {
		this.serv = serv;
	}
	
	@PostMapping("/add")
	public String addEmp(@RequestBody Emp emp) {
		return serv.addEmp(emp);
	}
	@GetMapping("/{empId}")
	public Emp getEmp(@PathVariable("empId")Integer empId) {
		return serv.getEmp(empId);
	}
	@PutMapping("/update/{empId}")
	public String updateEmp(@RequestBody Emp updateEmp ,@PathVariable("empId")Integer empId) {
		return serv.updateEmp(updateEmp, empId);
		
	}

}