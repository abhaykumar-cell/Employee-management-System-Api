package com.abhay.exception;

public class EmpAlreadyExistsException extends RuntimeException {
	public EmpAlreadyExistsException(String message)
	{	
		super(message);
	}

}
