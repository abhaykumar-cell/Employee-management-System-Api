package com.abhay.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(value=NoSuchEmpExistsExeption.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ResponseBody
	public ErrorResponse handleNoSuchEmpExistsExeption(NoSuchEmpExistsExeption ex) {
	ErrorResponse error =new ErrorResponse(HttpStatus.NOT_FOUND.value(),ex.getMessage());
	return error;
}
	@ExceptionHandler(value=EmpAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	@ResponseBody
	public ErrorResponse handleEmpAlreadyExistsException(EmpAlreadyExistsException ex) {
	ErrorResponse error =new ErrorResponse(HttpStatus.NOT_FOUND.value(),ex.getMessage());
	return error;
}

}
