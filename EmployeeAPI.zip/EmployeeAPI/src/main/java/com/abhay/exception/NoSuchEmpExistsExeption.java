package com.abhay.exception;

public class NoSuchEmpExistsExeption extends RuntimeException {

	public NoSuchEmpExistsExeption(String message) {
		super(message);
	}
	

}
